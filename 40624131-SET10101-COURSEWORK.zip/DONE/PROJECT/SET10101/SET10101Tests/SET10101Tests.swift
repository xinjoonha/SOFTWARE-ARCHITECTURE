//
//  SET10101Tests.swift
//  SET10101Tests
//
//  Created by 신준하 on 11/20/24.
//

import Testing
@testable import SET10101

struct SET10101Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
