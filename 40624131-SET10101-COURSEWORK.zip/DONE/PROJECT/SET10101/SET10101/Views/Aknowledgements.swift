//
//  Aknowledgements.swift
//  SET10101
//
//  Created by 신준하 on 11/23/24.
//

import SwiftUI

struct Aknowledgements: View
{
    var body: some View
    {
        VStack(alignment: .center, spacing: 12)
        {
            Text("40624131").font(.title)
            Text("Ihor Pisklov").font(.title)
            Text("November 2024").font(.title)
        }
    }
}

#Preview {
    Aknowledgements()
}
