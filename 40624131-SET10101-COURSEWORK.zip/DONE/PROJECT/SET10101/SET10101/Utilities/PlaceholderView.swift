//
//  PlaceholderView.swift
//  SET10101
//
//  Created by 신준하 on 11/20/24.
//

import SwiftUI

struct PlaceholderView: View
{
    var body: some View
    {
        Text("Placeholder view")
    }
}

#Preview {
    PlaceholderView()
}
